const { Events } = require("discord.js");
const tagalogReplies = require("./ysabelle_tagalog_replies.json");

const COOLDOWN_MS = 10_000;
const MAX_CACHE_SIZE = 5000;

const cooldowns = new Map();

function randomReply(replies) {
  return replies[Math.floor(Math.random() * replies.length)];
}

function normalizeText(text) {
  return text
    .toLocaleLowerCase("fil-PH")
    .normalize("NFKC")
    .replace(/[’‘]/g, "'")
    .replace(/\s+/g, " ")
    .trim();
}

function containsPhrase(content, phrase) {
  const normalizedPhrase = normalizeText(phrase);
  const escapedPhrase = normalizedPhrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  const pattern = new RegExp(
    `(^|[^\\p{L}\\p{N}])${escapedPhrase}([^\\p{L}\\p{N}]|$)`,
    "u",
  );

  return pattern.test(content);
}

function canReply(userId) {
  const now = Date.now();
  const lastReply = cooldowns.get(userId) || 0;

  if (now - lastReply < COOLDOWN_MS) {
    return false;
  }

  // Remove expired entries when the cache grows.
  if (cooldowns.size >= MAX_CACHE_SIZE) {
    for (const [id, timestamp] of cooldowns) {
      if (now - timestamp >= COOLDOWN_MS) {
        cooldowns.delete(id);
      }
    }

    if (cooldowns.size >= MAX_CACHE_SIZE) {
      return false;
    }
  }

  return true;
}

function findMatchingRule(content) {
  if (!Array.isArray(tagalogReplies.replies)) {
    return null;
  }

  return (
    tagalogReplies.replies.find((rule) => {
      if (!Array.isArray(rule.triggers) || !Array.isArray(rule.replies)) {
        return false;
      }

      return rule.triggers.some((trigger) => containsPhrase(content, trigger));
    }) || null
  );
}

async function handleAutoReply(message) {
  try {
    // Ignore bots and messages outside servers.
    if (message.author.bot || !message.guild) {
      return;
    }

    const content = normalizeText(message.content);

    if (!content) {
      return;
    }

    const client = message.client;

    if (!client.user) {
      return;
    }

    const mentionedYsabelle = message.mentions.users.has(client.user.id);

    const matchedRule = findMatchingRule(content);

    // Only reply to a known trigger or a direct mention.
    if (!mentionedYsabelle && !matchedRule) {
      return;
    }

    if (!canReply(message.author.id)) {
      return;
    }

    let response;

    if (mentionedYsabelle) {
      response = randomReply([
        "Present! Ano na naman 'yan? 👀",
        "Yes, beh? May chika ba o may kailangan ka lang? 😂",
        "Nandito ako. Sige, spill the tea! ☕",
        "Uy, tinawag mo ako? Ano 'yon? 💗",
      ]);
    } else {
      const validReplies = matchedRule.replies.filter(
        (reply) => typeof reply === "string" && reply.trim().length > 0,
      );

      if (validReplies.length === 0) {
        return;
      }

      response = randomReply(validReplies);
    }

    // Record cooldown immediately before sending.
    cooldowns.set(message.author.id, Date.now());

    await message.reply({
      content: response,
      allowedMentions: {
        repliedUser: false,
      },
    });
  } catch (error) {
    console.error("[Ysabelle AutoReply] Error:", error);
  }
}

function registerAutoReply(client) {
  client.on(Events.MessageCreate, handleAutoReply);
  console.log("[Ysabelle] Tagalog auto-reply handler loaded.");
}

module.exports = {
  registerAutoReply,
  handleAutoReply,
};
